<?php namespace ProcessWire;

class RepeaterMatrixPageArray extends RepeaterPageArray {
}